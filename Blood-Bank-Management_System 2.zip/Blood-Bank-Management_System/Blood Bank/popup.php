<!DOCTYPE html>
<html>
<body>

<button onclick="myFunction()">Try it</button>

<script>
function myFunction() {
    alert("Thank you for your kindness.Venue and other details will be sent to you via Email");
}
</script>

</body>
</html>
